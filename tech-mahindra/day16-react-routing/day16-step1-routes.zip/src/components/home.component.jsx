import { Component } from "react";

class HomeComp extends Component{
    render(){
        return <div>
                <h2>Home Component</h2>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Corrupti, fuga odio quisquam exercitationem, adipisci, beatae suscipit non optio enim nobis amet similique dolor quasi. Tempora assumenda qui consectetur unde obcaecati!
                </p>
               </div>
    }
}

export default HomeComp;