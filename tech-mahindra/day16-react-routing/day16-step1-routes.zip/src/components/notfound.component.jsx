import { Component } from "react";

class NotFoundComp extends Component{
    render(){
        return <div>
                <h2>404 : Requested Page NotFound</h2>
               </div>
    }
}

export default NotFoundComp;