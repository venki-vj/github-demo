import { Component } from "react";
import { Routes, Route, BrowserRouter, HashRouter, Link, NavLink } from "react-router-dom";
import HomeComp from "./components/home.component";
import HulkComp from "./components/hulk.component";
import IronmanComp from "./components/ironman.component";
import NotFoundComp from "./components/notfound.component";
import ScarletComp from "./components/scarlet.component";
import "./mystyle.css";

class MainApp extends Component{
    render(){
        return <div className="container">
                <h2>TechM Main Application</h2>
                <hr />
                <BrowserRouter>
                    {/* <ul>
                        <li> <a href="/">Home</a> </li>
                        <li> <a href="/ironman">Ironman</a> </li>
                        <li> <a href="/hulk">Hulk</a> </li>
                        <li> <a href="/scarlet">Scarlet</a> </li>
                        <li> <a href="/batman">Batman</a> </li>
                    </ul> */}

                   {/*  <ul className="nav justify-content-center">
                        <li className="nav-item"> <Link className="nav-link" to="/">Home</Link> </li>
                        <li className="nav-item"> <Link className="nav-link" to="/ironman">Ironman</Link> </li>
                        <li className="nav-item"> <Link className="nav-link" to="/hulk">Hulk</Link> </li>
                        <li className="nav-item"> <Link className="nav-link" to="/scarlet">Scarlet</Link> </li>
                        <li className="nav-item"> <Link className="nav-link" to="/batman">Batman</Link> </li>
                    </ul> */}

            <ul className="nav justify-content-center">
                <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? 'box nav-link' : 'nav-link'  } to="/">Home</NavLink> </li>
                <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? 'box nav-link' : 'nav-link'  } to="/ironman">Ironman</NavLink> </li>
                <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? 'box nav-link' : 'nav-link'  } to="/hulk">Hulk</NavLink> </li>
                <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? 'box nav-link' : 'nav-link'  } to="/scarlet">Scarlet</NavLink> </li>
                <li className="nav-item"> <NavLink className="nav-link" to="/batman">Batman</NavLink> </li>
            </ul>

                    <hr />

                    <Routes>
                        <Route path="/" element={<HomeComp/>}/>
                        <Route path="/hulk" element={<HulkComp/>}/>
                        <Route path="/ironman" element={<IronmanComp/>}/>
                        <Route path="/scarlet" element={<ScarletComp/>}/>
                        <Route path="*" element={<NotFoundComp/>}/>
                    </Routes>
                </BrowserRouter>
               </div>
    }
}

export default MainApp;