import { useState } from "react";
import UseEffectComp from "./components/useEffectComp";
import UseStateComp from "./components/useStateComp";

/* class MainApp extends Component{
    render(){
        return <div className="container">
                <h2>TechM Main Application</h2>
                <hr />
               </div>
    }
} */
/* const MainApp = function(){
return <div className="container">
            <h2>TechM Main Application</h2>
            <hr />
        </div>
} */
const MainApp = ()=> {
let [val, updateValue] = useState(5);
return <div className="container">
        <h2>TechM Main Application</h2>
        <input type="range" onChange={ (evt)=>updateValue(Number(evt.target.value)) } />
        <hr />
        <UseStateComp/>
        <hr />
        { val < 80 ? <UseEffectComp val={ val }/> : <h2>Component is unmounted</h2>}
        </div>
};

export default MainApp;