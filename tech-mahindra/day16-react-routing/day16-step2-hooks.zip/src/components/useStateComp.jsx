/* import { useState } from 'react';
let UseStateComp = ()=> {
    
  // console.log( useState() );

  let [ power, setPower ] = useState(0);
  let [ version, setVersion ] = useState(0);

  let clickHandler = ()=>{
      setPower(power+1)
  }

    return <div>
                <h2>Useing useState Hook</h2>
                <h3>Power : { power }</h3>
                <button onClick={ ()=> setPower(5) }>Set Power to 5</button>
                <button onClick={ ()=> setPower(power + 1) }>Increase Power</button>
                <button onClick={ ()=> setPower(power - 1) }>Decrease Power</button>
                <button onClick={ clickHandler }>Call Click Handler</button>

                <h3>version : { version }</h3>
                <button onClick={ ()=> setVersion(5) }>Set version to 5</button>
                <button onClick={ ()=> setVersion(version + 1) }>Increase version</button>
                <button onClick={ ()=> setVersion(version - 1) }>Decrease version</button>
            </div>
}
export default UseStateComp; */


import { useState } from 'react';
let UseStateComp = ()=> {
  let [ state, setState ] = useState({ power : 0, version : 0});
    return <div>
            <h2>Useing useState Hook</h2>
            <h3>Power : { state.power }</h3>
            <button onClick={ ()=> setState({ ...state, power : state.power + 1}) }>Increase Power</button>
            <button onClick={ ()=> setState({ ...state, power : state.power - 1}) }>Decrease Power</button>

            <h3>version : { state.version }</h3>
            <button onClick={ ()=> setState({ ...state, version : state.version + 1 }) }>Increase version</button>
            <button onClick={ ()=> setState({ ...state, version : state.version - 1 }) }>Decrease version</button>
            </div>
}
export default UseStateComp;