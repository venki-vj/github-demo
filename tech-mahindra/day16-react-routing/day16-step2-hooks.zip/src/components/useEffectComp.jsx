import { useEffect } from "react"

const UseEffectComp = (prop) => {
    useEffect(()=>{
        console.log("Component Mounted");
    },[]);
    useEffect(()=>{
        console.log("val updated", prop.val);
    },[prop.val]);
    useEffect(()=>{
        return ()=>{
            console.log("component is unmouted");
        }
    },[]);
/*     useEffect(()=>{
        console.log("component is mouted")
        return ()=>{
            console.log("component is unmouted")
        }
    },[prop.val]); */
    return <div>
                <h2>Use Effect Hook</h2>
                <h3>Value : {prop.val}</h3>
            </div>
}
export default UseEffectComp;