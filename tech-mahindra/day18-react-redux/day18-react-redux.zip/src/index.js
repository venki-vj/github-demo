import ReactDOM from "react-dom";
import MainApp from "./step2";
ReactDOM.render(<MainApp/>,document.getElementById("root"));
