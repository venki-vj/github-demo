import { useDispatch, useSelector } from "react-redux";
import { addHero } from "../redux";

let HeroHookComponent = ()=>{
    let numOfHeroes = useSelector( function( state ){ return state.numOfHeroes });
    let dispatch = useDispatch();

    return <div>
                <h2>Using React Redux With Hooks </h2>
                <h3>Number of Heroes : { numOfHeroes }</h3>
                <button onClick={ ()=> dispatch( addHero() )}>Add Hero</button>
            </div>
}

export default HeroHookComponent;