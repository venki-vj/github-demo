import React, { Component } from "react";
import axios from "axios";

class MainApp extends Component{
    state = {
        users : []
    }
    componentDidMount(){
        axios
        .get("http://localhost:3030/users")
        .then((res)=>this.setState({
            users : res.data
        }))
        .catch((error)=>console.log("Error : ", error));
    }
    render(){
        return <div className="container">
                    <h1>TechM MongoDB CRUD</h1>
                    <hr />
                    <ol>{this.state.users.map(res => <li key={res._id}>{res.username}</li>)}</ol>
                </div>
    }
}

export default MainApp;