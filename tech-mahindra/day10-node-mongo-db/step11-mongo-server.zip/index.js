const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
//-------------------------------
const app = express();
app.use(express.json());
app.use(cors());
//-------------------------------
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let User = mongoose.model("User", new Schema({
    id:ObjectId,
    username : String,
    usermail : String,
    usercity : String
}));


// let uri = "mongodb://localhost/techm";
let uri = "mongodb+srv://admin:password1234@vijaysdb.qamoa.mongodb.net/techMdb?retryWrites=true&w=majority";
mongoose.connect(uri).then(
    () => {
        console.log("Database is now connected")
    },
    (error) => {
        console.log("Error ", error)
    }
);
//-------------------------------
let userRoutes = express.Router();
    //READ
    userRoutes.route("/").get(function(req, res){
        User.find(function(err, users){
            if(err){
                console.log("Error : ", err)
            }else{
                res.json(users);
            }
        })
    })
    //CREATE
    userRoutes.route("/add").post(function(req, res){
        let user = new User(req.body);
        user.save().then( dbres => {
            res.status(200).json({ 'users' : 'User was added to the database' })
        }).catch( error => {
            res.status(400).send("user was not saved into database");
        })
    });
    //DELETE
    userRoutes.route("/delete/:id").get(function(req, res){
        User.findByIdAndDelete({ _id : req.params.id }, function(error, deleteduser){
            if(error){
                res.json({"error": error})
            }else{
                res.json({"deleteduser" : deleteduser})
            }
        })
    });
    // FIND USER TO UPDATE
    userRoutes.route("/edit/:id").get(function(req, res){
        User.findById(req.params.id, function(error, usertoedit){
            if(error){
                res.json({"error": error})
            }else{
                res.json(usertoedit)
            }
        })
    });

    // UPDATE USER INFO
    userRoutes.route("/edit/:id").post(function(req, res){
        User.findById(req.params.id, function(error, user){
            if(error){
                res.json({"error": error})
            }else{
                user.username = req.body.username;
                user.usermail = req.body.usermail;
                user.usercity = req.body.usercity;
                user.save().then( user => {
                    res.json(user);
                }).catch( error => {
                    res.status(400).send("user was not updated")
                })
            }
        })
    });
//-------------------------------
app.use('/users', userRoutes);
//-------------------------------
app.listen("3030", "localhost", (err) => {
    if(err){
        console.log("Error ", err);
    }else{
        console.log("Server is now live on localhost:3030");
    }
});