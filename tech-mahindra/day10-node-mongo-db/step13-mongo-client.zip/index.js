const express = require("express");
const app = express();
app.use(express.static(__dirname));
app.listen("4040");
console.log("server is now live on localhost : 4040");
