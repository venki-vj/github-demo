import { Component } from "react";
import { Provider } from "react-redux";
import UsersComp from "./components/users.component";
import store from "./redux/store";

class MainApp extends Component{
    render(){
        return <div className="container">
                    <h1>React Redux Axios</h1>
                    <hr />
                    <Provider store={ store }>
                        <UsersComp/>
                    </Provider>
                </div>
    }
}

export default MainApp;