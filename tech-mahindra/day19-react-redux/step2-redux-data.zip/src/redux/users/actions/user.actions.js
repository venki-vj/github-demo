import { AXIOS_USERS_REQUEST, AXIOS_USERS_RESPONSE, AXIOS_USERS_ERROR } from "../types/user.types";
import axios from "axios";

const axiosUsers = ()=>{
    return (dispatch)=>{
        dispatch( axiosUsersRequest() );
        setTimeout(()=>{
            axios
            .get("https://jsonplaceholder.typicode.com/users")
            .then( res =>  dispatch( axiosUsersResponse(res.data) ) )
            .catch(error => dispatch( axiosUsersError(error) ))
        }, 4000)
    }
}

const axiosUsersRequest = ()=>{
    return {
        type : AXIOS_USERS_REQUEST
    }
}
const axiosUsersResponse = (users)=>{
    return {
        type : AXIOS_USERS_RESPONSE,
        payload : users
    }
}
const axiosUsersError = (error)=>{
    return {
        type : AXIOS_USERS_ERROR,
        payload : error
    }
}

export {
    axiosUsers,
    axiosUsersRequest,
    axiosUsersResponse,
    axiosUsersError
}