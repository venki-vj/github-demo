import {  AXIOS_USERS_REQUEST, 
          AXIOS_USERS_RESPONSE, 
          AXIOS_USERS_ERROR } from "../types/user.types";

const initalState = {
    loading : false,
    users : [],
    error : ""
};

const userReducer = (state = initalState, action)=>{
    switch (action.type){
        case AXIOS_USERS_REQUEST : return{...state, loading : true }
        case AXIOS_USERS_RESPONSE : return{...state, loading : false, users : action.payload, error : "" }
        case AXIOS_USERS_ERROR : return{...state, loading : false, users : [], error : action.payload }
        default : return state
    }
}

export default userReducer;