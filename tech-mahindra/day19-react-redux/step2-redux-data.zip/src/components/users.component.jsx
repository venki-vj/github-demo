import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux";
import { axiosUsers } from "../redux/users/actions/user.actions";

const UsersComp = ()=>{
    const state = useSelector( state => state );
    const dispatch = useDispatch();

    useEffect(()=>{
        // console.log("Component is created");
        dispatch( axiosUsers() );
    },[])
    return <div>
                <h2>Users List</h2>
                <hr />
                { state.error !== '' && <p> { state.error.message } </p> }
                { state.loading &&  <h3> Loading Users... </h3> }
                <ol>{ state.users.map((user => <li key={user.id}>{ user.name }</li>))}</ol>
           </div>
}

export default UsersComp