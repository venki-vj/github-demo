const redux = require("redux");
const axios = require("axios");
const thunkMiddleWare = require("redux-thunk").default;

const createStore = redux.createStore;
const applyMiddleWare = redux.applyMiddleware;

// action
const AXIOS_USER_REQUEST = "AXIOS_USER_REQUEST";
const AXIOS_USER_SUCCESS = "AXIOS_USER_SUCCESS";
const AXIOS_USER_ERROR = "AXIOS_USER_ERROR";

// action creator
const usersRequest = ()=>{
    return {
        type : AXIOS_USER_REQUEST
    }
}
const usersRequestSuccess = (users)=>{
    return {
        type : AXIOS_USER_SUCCESS,
        payload : users
    }
}
const usersRequestError = (error)=>{
    return {
        type : AXIOS_USER_ERROR,
        payload : error
    }
}
// initial state
const initialState = {
    loading : false,
    users : [],
    error : ''
}
// reducers
const userReducer = (state = initialState, action)=>{
    switch(action.type){
        case AXIOS_USER_REQUEST : return { ...state, loading : true }
        case AXIOS_USER_SUCCESS : return { ...state, loading : false, users : action.payload, error : '' }
        case AXIOS_USER_ERROR : return { ...state, loading : false, users : [], error : action.payload }
        default : return state
    }
}
// create store
const store = createStore(userReducer, applyMiddleWare(thunkMiddleWare));

// subscribe / unsubscribe to store
store.subscribe(()=>{
    console.log(store.getState());
});

const thunkRequestUsers = ()=>{
    return function(dispatch){
        dispatch( usersRequest() );
    }
}

const thunkRequestResponseHandler = ()=>{
    return function(dispatch){
        axios
        .get("https://jsonplaceholder.typicode.com/users")
        .then( (res)=>{
            dispatch( usersRequestSuccess(res.data) );
        })
        .catch( (error)=>{
            dispatch( usersRequestError(error.message) );
        })
    }
}
// dispatchers
store.dispatch( thunkRequestUsers() );
store.dispatch( thunkRequestResponseHandler() );
// 
/*
npm init -y
npm i redux thunk axios
*/