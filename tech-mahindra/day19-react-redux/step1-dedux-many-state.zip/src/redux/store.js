import { createStore, combineReducers } from "redux";
import { heroReducer } from "./hero/reducers/hero.reducers";
import { movieReducer } from "./movie/reducers/movie.reducers";

const rootReducer = combineReducers({
    heroes : heroReducer,
    movies : movieReducer
})

const store = createStore(rootReducer);

export default store;