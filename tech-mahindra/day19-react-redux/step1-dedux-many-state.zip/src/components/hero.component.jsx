import { useDispatch, useSelector } from "react-redux";
import { addHero, removeHero } from "../redux/index";

let HeroComp = ()=>{
    let numOfHeroes = useSelector((state)=> state.heroes.numOfHeroes);
    let dispatch = useDispatch();
    return <div>
            <h2>Hero's Count : { numOfHeroes }</h2>
            <button className="btn btn-primary" onClick={ ()=> dispatch( addHero()) }>Add Hero</button>
            &nbsp;
            <button className="btn btn-warning" onClick={ ()=> dispatch( removeHero()) }>Remove Hero</button>
            </div>
}

export default HeroComp