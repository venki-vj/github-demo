import { Component } from "react"
import store from "./redux/store"
import { Provider } from "react-redux";
import HeroComp from "./components/hero.component";
import MovieComp from "./components/movie.component";

class MainApp extends Component{
    render(){
        return <div className="container">
                    <h1>Redux with multiple states</h1>
                    <Provider store={store}>
                        <HeroComp/>
                        <MovieComp/>
                    </Provider>
                </div>
    }
}

export default MainApp