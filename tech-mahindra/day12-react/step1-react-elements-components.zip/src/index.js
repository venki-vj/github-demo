import React, { Component } from "react";
import ReactDOM from "react-dom";

// let elm = React.createElement("h1",null,"Welcome to your life");

// let elm = <h1>Welcome to your life</h1>


let Elm = function(){
    let show = false;
    if(show){
        return <h1>Show is true</h1>
    }else{
        return <h1>Show is false</h1>
    }
} 

/* class Elm extends Component{
    render(){
        return <h1>Welcome to your life there's no turning back</h1>
    }
}
 */
ReactDOM.render(<Elm/>, document.getElementById("root"));