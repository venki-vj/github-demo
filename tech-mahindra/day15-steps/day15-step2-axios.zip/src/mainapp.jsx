import { Component } from "react";
import axios from "axios";

class MainApp extends Component{
    state = {
        users : []
    }
    componentDidMount(){
        axios
        .get("https://jsonplaceholder.typicode.com/users")
        .then((res)=>this.setState({
            users : res.data
        }))
    }
    render(){
        return <div className="container">
                <h1>TechM React App</h1>
                <ol>{ this.state.users.map(user=><li key={ user.id }>{ user.name }</li>)}</ol>
               </div>
    }
}

export default MainApp;