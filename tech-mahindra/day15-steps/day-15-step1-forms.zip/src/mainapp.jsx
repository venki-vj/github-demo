import { Component } from "react";
import FormApp from "./components/techm.forms";

class MainApp extends Component{
    render(){
        return <div className="container">
                <h1>TechM React App</h1>
                <hr />
                <FormApp/>
               </div>
    }
}

export default MainApp;