import { Component } from "react";
import HeroComp from "./components/hero.component";
class MainApp extends Component{
    state = {
        avengers : ['Ironman','Hulk','Vision','Antman','Scarlet','Black Widow'],
        justiceleague : ['Batman','Superman','Flash','Cyborg','Wonder Women','Aquaman']
    }
    render(){
        return <div>
                    <h1>Welcome to TechM Training</h1>
                    <HeroComp title="Avengers" heroes={this.state.avengers}/>
                    <HeroComp title="Justice League" heroes={this.state.justiceleague}/>
            </div>
       }
}
export default MainApp;