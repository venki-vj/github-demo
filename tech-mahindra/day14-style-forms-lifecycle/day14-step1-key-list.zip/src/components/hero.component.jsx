import React, { Component } from "react";

class HeroComp extends Component{
    render(){
        return <div>
                    <h2>{ this.props.title }</h2>
                    <ol>
                        {
                            this.props.heroes.map((val, idx)=><li key={idx}>{ val }</li>)
                        }
                    </ol>
               </div>
    }
}
export default HeroComp;