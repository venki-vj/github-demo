let inlineStyle = { 
    backgroundColor : "tomato", 
    color : "papayawhip", 
    borderRadius : "20px",
    padding : "10px", 
    fontFamily : "Arial" };

export { inlineStyle }
