import { Component } from "react";
import { inlineStyle } from "./comp-style";
import "./techm.css";

class MainApp extends Component{
    render(){
        
        return <div>
                    <h1>Welcome to TechM Training</h1>
                    <hr />
                   <p style={ { backgroundColor : "darkslateblue", color : "papayawhip", padding : "10px", fontFamily : "Arial" } }>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                    </p>
                    <p style={ inlineStyle }>
                        Default Style Color
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                    </p>
                    <p style={ {...inlineStyle, backgroundColor : "yellow", color : "black" } }>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                    </p>
                    <p className="techm">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                    </p>
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title">My Card</h5>
                            <p className="card-text">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quia ex, iure magni debitis autem voluptates maiores quaerat excepturi deserunt, animi quis recusandae qui consectetur impedit quo libero. Blanditiis, alias.
                            </p>    
                        </div>
                    </div>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, distinctio quos a reiciendis assumenda non facere explicabo eaque dolores. Reprehenderit fuga dolorem culpa eveniet excepturi ut hic modi maiores pariatur.
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Laudantium soluta dolor nesciunt similique consequatur? Illum, esse cum laudantium sequi ab unde sed officia, in, ex praesentium repudiandae delectus. Exercitationem, quaerat.
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam suscipit quasi incidunt quibusdam libero ab similique soluta magni nulla, consequatur perspiciatis fuga architecto commodi nobis excepturi ut quis voluptatem sapiente!
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente unde, incidunt, id at ullam quos vel dignissimos ratione accusamus sit quas animi pariatur voluptates saepe! Iste illum ratione eius quas.
                    </p>
              </div>
       }
}
export default MainApp;