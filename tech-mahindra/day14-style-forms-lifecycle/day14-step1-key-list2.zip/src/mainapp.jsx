import { Component } from "react";
import HeroComp from "./components/hero.component";
class MainApp extends Component{
    state = {
        avengers : ['Ironman','Hulk','Vision','Antman','Scarlet','Black Widow'],
        justiceleague : ['Batman','Superman','Flash','Cyborg','Wonder Women','Aquaman'],
        indicHeroes : ['Shaktiman','Krish','Chota Bheem'],
    }
    render(){
        return <div>
                    <h1>Welcome to TechM Training</h1>
                    <HeroComp title="Avengers" heroes={this.state.avengers}/>
                    <HeroComp title="Justice League" heroes={this.state.justiceleague}/>
                    <HeroComp title="Indic Heroes" heroes={this.state.indicHeroes}/>
            </div>
       }
}
export default MainApp;