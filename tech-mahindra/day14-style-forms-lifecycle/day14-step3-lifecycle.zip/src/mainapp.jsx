import { Component } from "react";
import ChildComp from "./components/child.component";

class MainApp extends Component{
    state = {
        power : 1
    }
    constructor(){
        super();
        console.log("MainApp's constructor was called");
    }
    componentDidMount(){
        console.log("MainApp's componentDidMount was called");
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    decreasePower = ()=>{
        this.setState({
            power : this.state.power - 1
        })
    }
    render(){
        console.log("MainApp's render was called");
        return <div className="container">
                    <h1>Welcome to TechM Training : Power { this.state.power }</h1>
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <button onClick={ this.decreasePower }>Decrease Power</button>
                    <hr />
                    { this.state.power < 15 ? <ChildComp childPower={this.state.power}/> : <h2>Component unmounted</h2>}
              </div>
       }
}
export default MainApp;