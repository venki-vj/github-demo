import { Component } from "react";
import FamilyContext from "../contexts/family.context";
import CousinComp from "./cousin.component";
import ParentComp from "./parent.component";
class GrandParentComp extends Component{
    state = {
        power : 0
    }
    render(){
        return <div style={ { border: "1px solid darkslategrey", padding : "10px", margin : "10px"} }>
                    <h1>GrandParent Component : power { this.state.power }</h1>
                    <hr />
                    <button className="btn btn-primary" onClick={()=>this.setState({power : Math.round(Math.random() * 1000)})}>Add Power</button>
                    <FamilyContext.Provider value={ this.state.power }>
                        <ParentComp/>
                        <CousinComp/>
                    </FamilyContext.Provider>
                </div>
    }
}
export default GrandParentComp;