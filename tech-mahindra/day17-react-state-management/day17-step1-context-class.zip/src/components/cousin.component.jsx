import { Component } from "react";
import FamilyContext from "../contexts/family.context";
class CousinComp extends Component{
    render(){
        return <div style={ { border: "1px solid darkslategrey", padding : "10px", margin : "10px"} }>
                    <h1>Cousin Component</h1>
                    <hr />
                    <FamilyContext.Consumer>{(value)=><h2>{value}</h2>}</FamilyContext.Consumer>
                </div>
    }
}
export default CousinComp;