const redux = require("redux");
const createStore = redux.createStore;
// action
const ADD_HERO = "ADD_HERO";
const REMOVE_HERO = "REMOVE_HERO";
const ADD_MOVIE = "ADD_MOVIE";
const REMOVE_MOVIE = "REMOVE_MOVIE";

// action creator
const addHero = ()=>{
    return { 
        type : ADD_HERO
     }
}
const removeHero = ()=>{
    return { 
        type : REMOVE_HERO
     }
}
const addMovie = ()=>{
    return { 
        type : ADD_MOVIE
     }
}
const removeMovie = ()=>{
    return { 
        type : REMOVE_MOVIE
     }
}

// initial / default state
const initialState = {
    numberOfHeroes : 0,
    numberOfMovies : 0
}

// reducer
const reducer = (state = initialState, action)=>{
    switch(action.type){
        case ADD_HERO : return { ...state, numberOfHeroes : state.numberOfHeroes + 1 }
        case REMOVE_HERO : return { ...state, numberOfHeroes : state.numberOfHeroes - 1 }
        case ADD_MOVIE : return { ...state, numberOfMovies : state.numberOfMovies + 1 }
        case REMOVE_MOVIE : return { ...state, numberOfMovies : state.numberOfMovies - 1 }
        default : return state
    }
}

// store
const store = createStore(reducer);

// subscribe
const unsubscribe = store.subscribe(()=>{
    console.log( store.getState() )
});

// dispatch action
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addMovie() );
store.dispatch( removeHero() );
store.dispatch( addHero() );
store.dispatch( removeHero() );
store.dispatch( addHero() );
store.dispatch( addMovie() );
store.dispatch( removeMovie() );
store.dispatch( addMovie() );
store.dispatch( removeMovie() );
store.dispatch( addMovie() );
unsubscribe();