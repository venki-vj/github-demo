const redux = require("redux");
const createStore = redux.createStore;
// action
const ADD_HERO = "ADD_HERO";

// action creator
const addHero = ()=>{
    return { 
        type : ADD_HERO
     }
}

// initial / default state
const initialState = {
    numberOfHeroes : 0
}

// reducer
const reducer = (state = initialState, action)=>{
    switch(action.type){
        case ADD_HERO : return {
            numberOfHeroes : state.numberOfHeroes + 1
        }
        default : return state
    }
}

// store
const store = createStore(reducer);

// subscribe
const unsubscribe = store.subscribe(()=>{
    console.log( store.getState() )
});

// dispatch action
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addHero() );
unsubscribe();
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( addHero() );