import { useContext } from "react";
import FamilyContext from "../contexts/family.context";
let ChildComp = ()=>{
    let value = useContext(FamilyContext);
    return <div style={ { border: "1px solid darkslategrey", padding : "10px", margin : "10px"} }>
                <h1>Child Component</h1>
                <hr />
                {/* <FamilyContext.Consumer>{(value)=><h2>{value}</h2>}</FamilyContext.Consumer> */}
                <h2>{value}</h2>
            </div>
}
export default ChildComp;