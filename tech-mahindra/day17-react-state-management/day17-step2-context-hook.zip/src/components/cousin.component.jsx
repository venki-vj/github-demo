import { useContext } from "react";
import FamilyContext from "../contexts/family.context";
let CousinComp = () => {
    let val = useContext(FamilyContext);
    return <div style={ { border: "1px solid darkslategrey", padding : "10px", margin : "10px"} }>
            <h1>Cousin Component</h1>
            <hr />
            <h2>{val}</h2>
        </div>
}
export default CousinComp;