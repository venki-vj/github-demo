import ChildComp from "./child.component";

let ParentComp = ()=> {
    return <div style={ { border: "1px solid darkslategrey", padding : "10px", margin : "10px"} }>
                <h1>Parent Component</h1>
                <hr />
                <ChildComp/>
            </div>
}

export default ParentComp;