import { useState } from "react";
import FamilyContext from "../contexts/family.context";
import CousinComp from "./cousin.component";
import ParentComp from "./parent.component";
let GrandParentComp = ()=>{
    let [power, setPower] = useState(0)
    return <div style={ { border: "1px solid darkslategrey", padding : "10px", margin : "10px"} }>
                    <h1>GrandParent Component : power { power }</h1>
                    <hr />
                    <button className="btn btn-primary" onClick={()=>setPower(Math.round(Math.random() * 1000))}>Add Power</button>
                    <FamilyContext.Provider value={ power }>
                        <ParentComp/>
                        <CousinComp/>
                    </FamilyContext.Provider>
                </div>
   
}
export default GrandParentComp;