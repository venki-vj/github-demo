import GrandParentComp from "./components/grandparent.component";

let MainApp = () => {
    return <div className="container">
                <h1>TechM Context API</h1>
                <hr />
                <GrandParentComp/>
            </div>
}

export default MainApp;