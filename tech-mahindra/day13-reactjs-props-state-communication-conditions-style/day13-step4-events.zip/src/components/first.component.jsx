import React, { Component } from "react";

class FirstComp extends Component{
    state = {
        power : 1
    }
    numRef = React.createRef();
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    increasePowerFromRange = (evt)=>{
        this.setState({
            power : Number(evt.target.value)
        })
    }
    increasePowerFromNumber = ()=>{
        this.setState({
            power : Number( this.numRef.current.value )
        })
    }
    render(){
        return <div>
                    <h2>Power : { this.state.power }</h2>
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <br/>
                    <input min={5} max={50} step={5} onChange={ this.increasePowerFromRange } type="range" />
                    <br/>
                    <input ref={ this.numRef } type="number" />
                    <button onClick={ this.increasePowerFromNumber }>Incease Power to... </button>
                </div>
    }
}
export default FirstComp;