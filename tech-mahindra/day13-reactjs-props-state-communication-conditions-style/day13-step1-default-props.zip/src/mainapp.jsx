import { Component } from "react";
import FirstComp from "./components/first.component";
class MainApp extends Component{
    render(){
        return <div>
                    <h1>Welcome to TechM Training</h1>
                    <FirstComp title="TechM application" ver={1001} >Hello First Component</FirstComp>
                    <FirstComp ver={1002} >Hello Second Component</FirstComp>
                    <FirstComp title="TechM application">Hello Third Component </FirstComp>
                    <FirstComp>Hello Fourth Component</FirstComp>
               </div>
}}
export default MainApp;