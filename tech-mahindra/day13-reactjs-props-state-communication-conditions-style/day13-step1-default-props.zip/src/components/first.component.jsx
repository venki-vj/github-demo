import { Component } from "react"
class FirstComp extends Component{
    static defaultProps = {
        title : "Default Title",
        ver : 0.5
    }
    render(){
        return <div>
                    <h2>Title : { this.props.title }</h2>
                    <h3>Message : { this.props.children }</h3>
                    <h3>Version : { this.props.ver + 2 }</h3>
                </div>
    }
}
/* FirstComp.defaultProps = {
    title : "Default Title",
    ver : 0
} */
export default FirstComp;