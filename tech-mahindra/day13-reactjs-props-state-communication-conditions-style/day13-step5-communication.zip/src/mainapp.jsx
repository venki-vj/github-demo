import { Component } from "react";
import FirstComp from "./components/first.component";
class MainApp extends Component{
    state = {
        power : 0,
        message : "Message from parent"
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    decreasePower = ()=>{
        this.setState({
            power : this.state.power - 1
        })
    }
    changeMessage = ()=>{
        this.setState({
            message : "Changed"
        })
    }
    setMessage = (nmessage)=>{
        this.setState({
            message : nmessage
        })
    }
    render(){
        return <div>
                    <h1>Welcome to TechM Training</h1>
                    <h2>Power :  | { this.state.power }</h2>
                    <h2>Message :  | { this.state.message }</h2>
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <button onClick={ this.decreasePower }>Decrease Power</button>
                    <button onClick={ this.changeMessage }>Change Message</button>
                    <hr />
                    <FirstComp 
                    setMess={ this.setMessage }
                    incPow={ this.increasePower } 
                    decPow={ this.decreasePower }  
                    message={ this.state.message } 
                    pow={ this.state.power }/>
               </div>
}}
export default MainApp;