import React, { Component } from "react";

class FirstComp extends Component{
    render(){
        return <div>
                    <h2>Power : { this.props.pow }</h2>
                    <h2>Message : { this.props.message }</h2>
                    <button onClick={ this.props.incPow }> Increase Power from First Comp </button>
                    <button onClick={ this.props.decPow }> Decrease Power from First Comp </button>
                    <input onChange={ (evt)=>this.props.setMess(evt.target.value) } />
               </div>
    }
}
export default FirstComp;