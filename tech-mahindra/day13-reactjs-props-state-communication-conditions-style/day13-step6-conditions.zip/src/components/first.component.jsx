import React, { Component } from "react";

class FirstComp extends Component{
    render(){
        return <div>
                    <h2>First Component Title</h2>
               </div>
    }
}
export default FirstComp;