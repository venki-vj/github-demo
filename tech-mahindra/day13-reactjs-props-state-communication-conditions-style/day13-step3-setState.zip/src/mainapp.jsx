import { Component } from "react";
import FirstComp from "./components/first.component";
class MainApp extends Component{
    version = 1001;
    render(){
        return <div>
                    <h1>Welcome to TechM Training</h1>
                    <FirstComp title="TechM application" ver={this.version} >Hello First Component</FirstComp>
               </div>
}}
export default MainApp;