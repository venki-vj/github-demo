import { Component } from "react"
class FirstComp extends Component{
    // power = 1;
    state = {
        power : 1
    }
    render(){
        return <div>
                    <h2>Title : { this.props.title }</h2>
                    <h3>Message : { this.props.children }</h3>
                    <h3>Version : { this.props.ver + 2 }</h3>
                    <h3>Power : { this.state.power }</h3>
                   {/*  <button onClick={ ()=>{
                        this.power += 1;
                        console.log(this.power);
                        this.forceUpdate();
                    } }>Increase Power</button> */}
                    <button onClick={ ()=>{
                        this.setState({ power : this.state.power +1 });
                    } }>Increase Power</button>
                </div>
    }
}
export default FirstComp;

/*
Props are read only value
custom properties when modified wont render the view
use the forceUpdate method to call render method manually
*/